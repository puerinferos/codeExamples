﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecoverBlocksEnemy : AbstractEnemy
{
    protected override void Update()
    {
        base.Update();
        if (_battlefieldManager.deletedBlocks.Count > 0)
        {
            if (_timer < _superReloadTime)
                _timer += Time.deltaTime;
					
            if(_timer >= _superReloadTime-1)
                if(_unityArmatureComponent.armature.animation.lastAnimationName != "Super")
                    _unityArmatureComponent.animation.FadeIn("Super",.3f, 1);
					
            if (_timer >= _superReloadTime)
            {
                EnemySuper();
						
                _timer = 0;
            }
        }
    }

    public override void EnemySuper()
    {
            Transform blockToRestore = _battlefieldManager.deletedBlocks[Random.Range(0, _battlefieldManager.deletedBlocks.Count - 1)];
            blockToRestore.gameObject.SetActive(true);
            _battlefieldManager.deletedBlocks.Remove(blockToRestore);
    }
}
