﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stones : MonoBehaviour
{
    public List<SpriteRenderer> stonePrefabs;
    private int _numOfStones;

    private List<Sprite> stoneSprites;
    private Camera _mainCamera;
    private AbstractEnemy _enemy;

    private void Start()
    {
        _mainCamera = Camera.main;
        
        InitStonesTextures();
        
        for (var i = 0; i < _numOfStones; i++)
        {
            var stoneClone = Instantiate(stonePrefabs[_numOfStones-3], transform);
            var stoneCollider = stoneClone.GetComponent<Collider2D>();
            stoneClone.sprite = stoneSprites[_numOfStones-3];
            stoneClone.transform.localPosition = i == 0 ? 
                new Vector3(0,-_mainCamera.orthographicSize + _mainCamera.transform.position.y+stoneCollider.bounds.size.y/2)
                : new Vector3(0,transform.GetChild(i-1).position.y + stoneCollider.bounds.size.y);
            if (i == _numOfStones - 1)
                _enemy.transform.localPosition = new Vector3(0,
                    transform.GetChild(i).position.y + _enemy.GetComponent<Collider2D>().bounds.size.y/2);
        }
    }

    public void Constructor(int numOfStones,AbstractEnemy enemy)
    {
        _numOfStones = numOfStones;
        _enemy = enemy;
    }
    
    public void InitStonesTextures()
    {
        stoneSprites = new List<Sprite>();
        if(stoneSprites.Count > 0)
            stoneSprites.Clear();
        var stoneName = "stones000";
        if (!PlayerPrefs.HasKey("Map")) PlayerPrefs.SetInt("Map",1);
        for (var i = 1; i < 8; i++)
        {
            switch (PlayerPrefs.GetInt("Map"))
            {
                case 1:
                    stoneSprites.Add(Resources.Load<Sprite>("Sprites/Stones/North/" + stoneName + i.ToString()));
                    break;
                case 2:
                    stoneSprites.Add(Resources.Load<Sprite>("Sprites/Stones/Desert/" + stoneName + i.ToString()));
                    break;
                case 3:
                    stoneSprites.Add(Resources.Load<Sprite>("Sprites/Stones/Wood/" + stoneName + i.ToString()));
                    break;
            }
        }
    }

    public void Hit()
    {
        foreach (Transform child in transform)
        {
            if (child.GetSiblingIndex() >= _enemy._hp)
                child.gameObject.SetActive(false);
        }
    }

    public void Heal()
    {
        foreach (Transform child in transform)
        {
            if (child.GetSiblingIndex() < _enemy._hp)
                child.gameObject.SetActive(true);
        }
    }
    
    public void Update()
    {
        Hit();
    }
}
