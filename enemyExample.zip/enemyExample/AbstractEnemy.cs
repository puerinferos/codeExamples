﻿using System;
using System.Collections;
using System.Collections.Generic;
using DragonBones;
using UnityEngine;
using Random = UnityEngine.Random;
using Transform = UnityEngine.Transform;

public enum StandardEnemyAnimationName
{
    Idle,
    Damage,
    Deat,
    Super
}
public abstract class AbstractEnemy : MonoBehaviour
{
    public int _hp = 0;
    
    protected DragonBones.UnityArmatureComponent _unityArmatureComponent;
    protected List<BoxCollider2D> _colliders;
    [SerializeField] protected List<AudioClip> _hitClips;
    
    protected AudioSource _audioSource;

    protected Stones _stones;
    protected float _timer;
    protected float _superReloadTime;
    protected UIManager _uiManager;
    protected BattlefieldManager _battlefieldManager;
    protected Camera mainCamera;


    protected virtual void Start()
    {
        _unityArmatureComponent.SetAnimation(StandardEnemyAnimationName.Idle.ToString());
    }

    public virtual void Constructor(AudioSource audioSource,List<AudioClip> hitClips,int hp,float superReloadTime,UIManager uiManager,BattlefieldManager battlefieldManager,Stones stones)
    {
        _audioSource = audioSource;
        _hitClips = hitClips;
        _hp = hp;
        _superReloadTime = superReloadTime;
        _uiManager = uiManager;
        _battlefieldManager = battlefieldManager;
        _stones = stones;
        
        _unityArmatureComponent = GetComponent<DragonBones.UnityArmatureComponent>();
        mainCamera = Camera.main;
        
    }

    protected virtual void Update()
    {
        transform.position = new Vector3(transform.position.x,Mathf.Clamp(transform.position.y,
            -mainCamera.orthographicSize + mainCamera.transform.position.y,
            20),transform.position.z);
        
        if (!_unityArmatureComponent.animation.isPlaying &&
            _unityArmatureComponent.armature.animation.lastAnimationName != StandardEnemyAnimationName.Deat.ToString())
            _unityArmatureComponent.animation.FadeIn(StandardEnemyAnimationName.Idle.ToString(),.1f, 1);

    }

    public virtual void EnemyHit(int n)
    {
        _audioSource.clip = _hitClips[Random.Range(0, _hitClips.Count - 1)];
        _audioSource.Play();

        if(_unityArmatureComponent.armature.animation.lastAnimationName != StandardEnemyAnimationName.Deat.ToString())
            _unityArmatureComponent.animation.FadeIn(StandardEnemyAnimationName.Damage.ToString(),.1f, 1);
        
        _uiManager.AddMoney(9);
        
        if (_hp == 1) n = 1;
        _hp -= n;

        if (_hp == 0)
        {
            _unityArmatureComponent.animation.FadeIn(StandardEnemyAnimationName.Deat.ToString(),.1f, 1);
            _uiManager.gameIsOver = true;
        }
    }

    public virtual void EnemySuper()
    {
        if(_unityArmatureComponent.armature.animation.lastAnimationName != StandardEnemyAnimationName.Deat.ToString())
        _unityArmatureComponent.animation.FadeIn(StandardEnemyAnimationName.Super.ToString(),.3f, 1);
    }
}
