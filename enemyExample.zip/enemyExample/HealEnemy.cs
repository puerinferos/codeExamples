﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealEnemy : AbstractEnemy
{
    protected override void Update()
    {
        base.Update();
        if (_hp < _stones.transform.childCount)
        {
					
            if (_timer < _superReloadTime)
                _timer += Time.deltaTime;
					
            if(_timer >= _superReloadTime-2)
                if(_unityArmatureComponent.armature.animation.lastAnimationName != "Super")
                    _unityArmatureComponent.animation.FadeIn("Super",.3f, 1);
					
            if (_timer >= _superReloadTime)
            {
                _hp++;
                _stones.Heal();
						
                _timer = 0;
            }
        }    
    }
}
