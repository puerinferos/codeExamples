﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpingEnemy : AbstractEnemy
{
    protected override void Update()
    {
        base.Update();
        if(_timer < _superReloadTime) _timer += Time.deltaTime;
        else
        {
            EnemySuper();
            _timer = 0;
        }
    }
}
